var searchData=
[
  ['add_5ftask_5fwindow_2examl_2ecs_0',['Add_Task_Window.xaml.cs',['../Add__Task__Window_8xaml_8cs.html',1,'']]],
  ['app_2examl_2ecs_1',['App.xaml.cs',['../App_8xaml_8cs.html',1,'']]]
];
