var searchData=
[
  ['basic_5fcity_0',['Basic_City',['../classKalendarz_1_1MainWindow.html#aa31a53966376629a1aef8b3162d273b3',1,'Kalendarz.MainWindow.Basic_City()'],['../classKalendarz_1_1Weather__Window.html#aa31a53966376629a1aef8b3162d273b3',1,'Kalendarz.Weather_Window.Basic_City()']]]
];
