var searchData=
[
  ['basic_5fcity_0',['Basic_City',['../class_kalendarz_1_1_main_window.html#a3040e7ce99cd4cf8c54289a3824e1b6b',1,'Kalendarz::MainWindow']]]
];
