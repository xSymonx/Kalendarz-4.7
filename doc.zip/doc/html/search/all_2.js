var searchData=
[
  ['coord_0',['coord',['../class_kalendarz_1_1_weather_api_1_1coord.html',1,'Kalendarz::WeatherApi']]]
];
