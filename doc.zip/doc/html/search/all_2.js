var searchData=
[
  ['coord_0',['coord',['../classKalendarz_1_1WeatherApi_1_1WeatherInfo.html#aefd33142b49fdec43564d236ea579a97',1,'Kalendarz.WeatherApi.WeatherInfo.coord()'],['../classKalendarz_1_1WeatherApi_1_1coord.html',1,'WeatherApi.coord']]],
  ['country_1',['country',['../classKalendarz_1_1WeatherApi_1_1sys.html#a0fd9d6d8d6f20ed4d1ee3b221a29d522',1,'Kalendarz::WeatherApi::sys']]]
];
