var searchData=
[
  ['blank_0',['Blank',['../class_kalendarz_1_1_blank.html#a71722048050c2e61a8002f857aa8bf8c',1,'Kalendarz::Blank']]]
];
