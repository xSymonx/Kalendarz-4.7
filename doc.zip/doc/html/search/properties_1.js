var searchData=
[
  ['data_0',['Data',['../class_kalendarz_1_1_task.html#a44abcfcb459ce0698663df51ab68393e',1,'Kalendarz::Task']]]
];
