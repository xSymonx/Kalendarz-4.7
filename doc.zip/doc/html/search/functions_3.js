var searchData=
[
  ['mainwindow_0',['MainWindow',['../class_kalendarz_1_1_main_window.html#a8920924b405e5c1da603a4bf92fe05e0',1,'Kalendarz::MainWindow']]]
];
