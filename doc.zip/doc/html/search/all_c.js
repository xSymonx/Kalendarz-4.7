var searchData=
[
  ['pressure_0',['pressure',['../classKalendarz_1_1WeatherApi_1_1main.html#aee1c5d07ac79c5c036195858afe33405',1,'Kalendarz::WeatherApi::main']]]
];
