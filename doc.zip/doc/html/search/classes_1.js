var searchData=
[
  ['blank_0',['Blank',['../class_kalendarz_1_1_blank.html',1,'Kalendarz']]]
];
