var searchData=
[
  ['blank_0',['Blank',['../classKalendarz_1_1Blank.html',1,'Kalendarz']]]
];
