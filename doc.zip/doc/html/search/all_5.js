var searchData=
[
  ['kalendarz_0',['Kalendarz',['../namespace_kalendarz.html',1,'']]]
];
