var searchData=
[
  ['feels_5flike_0',['feels_like',['../classKalendarz_1_1WeatherApi_1_1main.html#ab50ed9201d843f503dfd66611c91631d',1,'Kalendarz::WeatherApi::main']]]
];
