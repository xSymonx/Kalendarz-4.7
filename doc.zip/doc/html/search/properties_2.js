var searchData=
[
  ['data_0',['Data',['../classKalendarz_1_1Task.html#a0df039919c9cd4ab27611e3addb611c1',1,'Kalendarz::Task']]],
  ['description_1',['description',['../classKalendarz_1_1WeatherApi_1_1weather.html#a23af17c78302b71c14ef38ea40b8d1d7',1,'Kalendarz::WeatherApi::weather']]]
];
