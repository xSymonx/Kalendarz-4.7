var searchData=
[
  ['task_0',['Task',['../class_kalendarz_1_1_task.html',1,'Kalendarz']]],
  ['taskcontext_1',['TaskContext',['../class_kalendarz_1_1_task_context.html',1,'Kalendarz']]]
];
