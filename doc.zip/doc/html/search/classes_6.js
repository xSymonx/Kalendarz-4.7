var searchData=
[
  ['task_0',['Task',['../classKalendarz_1_1Task.html',1,'Kalendarz']]],
  ['taskcontext_1',['TaskContext',['../classKalendarz_1_1TaskContext.html',1,'Kalendarz']]]
];
