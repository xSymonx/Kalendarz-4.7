var searchData=
[
  ['unixtimestamptodatetime_0',['UnixTimeStampToDateTime',['../classKalendarz_1_1Weather__Window.html#a6c99ee309e1b876d2375ac252ec0d304',1,'Kalendarz::Weather_Window']]],
  ['update_5fweather_1',['Update_Weather',['../classKalendarz_1_1MainWindow.html#a5601df748daa8ec9803f5ad79dffcc8c',1,'Kalendarz.MainWindow.Update_Weather()'],['../classKalendarz_1_1Weather__Window.html#a5601df748daa8ec9803f5ad79dffcc8c',1,'Kalendarz.Weather_Window.Update_Weather()']]]
];
