var searchData=
[
  ['coord_0',['coord',['../classKalendarz_1_1WeatherApi_1_1coord.html',1,'Kalendarz::WeatherApi']]]
];
