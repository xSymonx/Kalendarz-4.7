var searchData=
[
  ['data_0',['Data',['../class_kalendarz_1_1_task.html#a44abcfcb459ce0698663df51ab68393e',1,'Kalendarz::Task']]],
  ['days_1',['days',['../class_kalendarz_1_1_days.html#a420b4554d0ed8dec72e9d74eb71bf05b',1,'Kalendarz::Days']]],
  ['days_2',['Days',['../class_kalendarz_1_1_days.html#af45e8bbc0f52fdbd9b327191d8e36078',1,'Kalendarz.Days.Days()'],['../class_kalendarz_1_1_days.html',1,'Kalendarz.Days']]],
  ['delete_5ftask_5fwindow_3',['Delete_Task_Window',['../class_kalendarz_1_1_delete___task___window.html#a43fbf2273185f9fca6cb81273dc12c7b',1,'Kalendarz.Delete_Task_Window.Delete_Task_Window()'],['../class_kalendarz_1_1_delete___task___window.html',1,'Kalendarz.Delete_Task_Window']]],
  ['deletetask_4',['DeleteTask',['../class_kalendarz_1_1_delete___task___window.html#a178bb5c3e6667d07ac45f9d11b7dc438',1,'Kalendarz::Delete_Task_Window']]]
];
