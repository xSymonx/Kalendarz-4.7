var searchData=
[
  ['days_0',['Days',['../class_kalendarz_1_1_days.html',1,'Kalendarz']]],
  ['delete_5ftask_5fwindow_1',['Delete_Task_Window',['../class_kalendarz_1_1_delete___task___window.html',1,'Kalendarz']]]
];
