var searchData=
[
  ['days_0',['Days',['../classKalendarz_1_1Days.html',1,'Kalendarz']]],
  ['delete_5ftask_5fwindow_1',['Delete_Task_Window',['../classKalendarz_1_1Delete__Task__Window.html',1,'Kalendarz']]]
];
