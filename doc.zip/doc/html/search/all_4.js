var searchData=
[
  ['exit_5fclick_0',['Exit_Click',['../classKalendarz_1_1Add__Task__Window.html#ae1288ac3666e95211f74068e97f231bc',1,'Kalendarz.Add_Task_Window.Exit_Click()'],['../classKalendarz_1_1Delete__Task__Window.html#ae1288ac3666e95211f74068e97f231bc',1,'Kalendarz.Delete_Task_Window.Exit_Click()'],['../classKalendarz_1_1MainWindow.html#ae1288ac3666e95211f74068e97f231bc',1,'Kalendarz.MainWindow.Exit_Click()'],['../classKalendarz_1_1Weather__Window.html#ae1288ac3666e95211f74068e97f231bc',1,'Kalendarz.Weather_Window.Exit_Click()']]]
];
