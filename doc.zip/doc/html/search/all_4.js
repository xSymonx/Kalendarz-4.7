var searchData=
[
  ['id_0',['ID',['../class_kalendarz_1_1_task.html#a5d493e08313d029d729ae823c7df54a3',1,'Kalendarz::Task']]]
];
