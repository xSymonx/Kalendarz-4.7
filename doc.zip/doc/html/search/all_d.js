var searchData=
[
  ['readme_0',['README',['../md_C__Users_dell_source_repos_xSymonx_Kalendarz_4_7_README.html',1,'']]],
  ['readme_2emd_1',['README.md',['../README_8md.html',1,'']]],
  ['refresh_5fweather_5fclick_2',['Refresh_Weather_Click',['../classKalendarz_1_1MainWindow.html#af269e45266c4372796f30c1bb8fc577a',1,'Kalendarz::MainWindow']]],
  ['right_5farrow_5fclick_3',['Right_Arrow_Click',['../classKalendarz_1_1MainWindow.html#a5c4f4c2e97f68bc6a7bc3d5d156c2161',1,'Kalendarz::MainWindow']]]
];
