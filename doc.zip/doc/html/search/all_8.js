var searchData=
[
  ['kalendarz_0',['Kalendarz',['../namespaceKalendarz.html',1,'']]]
];
