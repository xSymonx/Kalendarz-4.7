var searchData=
[
  ['readme_0',['README',['../md__r_e_a_d_m_e.html',1,'']]],
  ['right_5farrow_5fclick_1',['Right_Arrow_Click',['../class_kalendarz_1_1_main_window.html#a4bdbb93c20493998f1b6e190a196b165',1,'Kalendarz::MainWindow']]]
];
