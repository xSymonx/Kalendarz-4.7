var searchData=
[
  ['weather_5fwindow_0',['Weather_Window',['../classKalendarz_1_1Weather__Window.html#a14aa59a56cb51fde25e4e246ba3c5809',1,'Kalendarz::Weather_Window']]]
];
