var searchData=
[
  ['task_5findex_0',['Task_Index',['../class_kalendarz_1_1_delete___task___window.html#a1db245232d84183514faf21ec2d1780c',1,'Kalendarz::Delete_Task_Window']]],
  ['tasks_1',['Tasks',['../class_kalendarz_1_1_task_context.html#a585d151339cdcc3bffc9b6a64bed927f',1,'Kalendarz::TaskContext']]]
];
