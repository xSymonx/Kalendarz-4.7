var searchData=
[
  ['task_5findex_0',['Task_Index',['../class_kalendarz_1_1_delete___task___window.html#a1db245232d84183514faf21ec2d1780c',1,'Kalendarz::Delete_Task_Window']]]
];
