var searchData=
[
  ['blank_2examl_2ecs_0',['Blank.xaml.cs',['../Blank_8xaml_8cs.html',1,'']]]
];
