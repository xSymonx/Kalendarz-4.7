var searchData=
[
  ['taskcontext_0',['TaskContext',['../class_kalendarz_1_1_task_context.html#a3300fa99c1975ef87b06b7be7afde33a',1,'Kalendarz::TaskContext']]]
];
