var searchData=
[
  ['refresh_5fweather_5fclick_0',['Refresh_Weather_Click',['../classKalendarz_1_1MainWindow.html#af269e45266c4372796f30c1bb8fc577a',1,'Kalendarz::MainWindow']]],
  ['right_5farrow_5fclick_1',['Right_Arrow_Click',['../classKalendarz_1_1MainWindow.html#a5c4f4c2e97f68bc6a7bc3d5d156c2161',1,'Kalendarz::MainWindow']]]
];
