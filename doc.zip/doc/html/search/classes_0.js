var searchData=
[
  ['add_5ftask_5fwindow_0',['Add_Task_Window',['../classKalendarz_1_1Add__Task__Window.html',1,'Kalendarz']]],
  ['app_1',['App',['../classKalendarz_1_1App.html',1,'Kalendarz']]]
];
