var searchData=
[
  ['add_5ftask_5fwindow_0',['Add_Task_Window',['../class_kalendarz_1_1_add___task___window.html',1,'Kalendarz']]],
  ['app_1',['App',['../class_kalendarz_1_1_app.html',1,'Kalendarz']]]
];
