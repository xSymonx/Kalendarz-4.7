var searchData=
[
  ['icon_0',['icon',['../classKalendarz_1_1WeatherApi_1_1weather.html#ac8d9406f640b46f65573a181bb453884',1,'Kalendarz::WeatherApi::weather']]],
  ['id_1',['ID',['../classKalendarz_1_1Task.html#af180e926633cde08a05ccbc3af397ee4',1,'Kalendarz::Task']]]
];
