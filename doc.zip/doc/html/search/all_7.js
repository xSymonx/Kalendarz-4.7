var searchData=
[
  ['nazwa_0',['Nazwa',['../class_kalendarz_1_1_task.html#aeb8760d6c0f1d7a935047c7d7879f29e',1,'Kalendarz::Task']]],
  ['notes_1',['Notes',['../class_kalendarz_1_1_main_window.html#aff0da900297a9031e158439466b80049',1,'Kalendarz::MainWindow']]]
];
