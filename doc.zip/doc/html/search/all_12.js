var searchData=
[
  ['year_0',['year',['../classKalendarz_1_1MainWindow.html#abeac221e38b7b9ce7df8722c842bf671',1,'Kalendarz::MainWindow']]]
];
