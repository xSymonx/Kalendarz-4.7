var searchData=
[
  ['left_5farrow_5fclick_0',['Left_Arrow_Click',['../classKalendarz_1_1MainWindow.html#afa3e1abfb3ea571b45cdfe41e9d853da',1,'Kalendarz::MainWindow']]]
];
