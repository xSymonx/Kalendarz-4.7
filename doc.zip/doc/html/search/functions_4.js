var searchData=
[
  ['right_5farrow_5fclick_0',['Right_Arrow_Click',['../class_kalendarz_1_1_main_window.html#a4bdbb93c20493998f1b6e190a196b165',1,'Kalendarz::MainWindow']]]
];
