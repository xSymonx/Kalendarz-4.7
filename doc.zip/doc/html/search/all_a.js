var searchData=
[
  ['task_0',['Task',['../class_kalendarz_1_1_task.html',1,'Kalendarz']]],
  ['task_5findex_1',['Task_Index',['../class_kalendarz_1_1_delete___task___window.html#a1db245232d84183514faf21ec2d1780c',1,'Kalendarz::Delete_Task_Window']]],
  ['taskcontext_2',['TaskContext',['../class_kalendarz_1_1_task_context.html',1,'Kalendarz.TaskContext'],['../class_kalendarz_1_1_task_context.html#a3300fa99c1975ef87b06b7be7afde33a',1,'Kalendarz.TaskContext.TaskContext()']]],
  ['tasks_3',['Tasks',['../class_kalendarz_1_1_task_context.html#a585d151339cdcc3bffc9b6a64bed927f',1,'Kalendarz::TaskContext']]]
];
