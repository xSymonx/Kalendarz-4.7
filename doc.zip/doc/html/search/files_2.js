var searchData=
[
  ['days_2examl_2ecs_0',['Days.xaml.cs',['../Days_8xaml_8cs.html',1,'']]],
  ['delete_5ftask_5fwindow_2examl_2ecs_1',['Delete_Task_Window.xaml.cs',['../Delete__Task__Window_8xaml_8cs.html',1,'']]]
];
