var searchData=
[
  ['static_5fdate_0',['static_date',['../class_kalendarz_1_1_main_window.html#ac10c4fc7d1489920194848cd109b4dcb',1,'Kalendarz::MainWindow']]],
  ['static_5fmonth_1',['static_month',['../class_kalendarz_1_1_main_window.html#afa0ed90be8cf18c3b6f301975763c2b5',1,'Kalendarz::MainWindow']]],
  ['static_5fyear_2',['static_year',['../class_kalendarz_1_1_main_window.html#a88daea711c1e054da721555863ee0103',1,'Kalendarz::MainWindow']]]
];
