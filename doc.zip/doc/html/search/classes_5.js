var searchData=
[
  ['sys_0',['sys',['../classKalendarz_1_1WeatherApi_1_1sys.html',1,'Kalendarz::WeatherApi']]]
];
