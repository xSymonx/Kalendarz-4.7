var searchData=
[
  ['sys_0',['sys',['../class_kalendarz_1_1_weather_api_1_1sys.html',1,'Kalendarz::WeatherApi']]]
];
