var searchData=
[
  ['nazwa_0',['Nazwa',['../classKalendarz_1_1Task.html#ab296402b9c502c4437204d6c6bce3726',1,'Kalendarz::Task']]],
  ['notes_1',['Notes',['../classKalendarz_1_1MainWindow.html#a92c1fa6781c861c86633b065b65d4587',1,'Kalendarz::MainWindow']]]
];
