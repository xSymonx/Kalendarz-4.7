var searchData=
[
  ['months_0',['Months',['../class_kalendarz_1_1_main_window.html#a4fbca0aa572404c046eaa891da2eccf1',1,'Kalendarz::MainWindow']]]
];
