var searchData=
[
  ['static_5fday_0',['static_day',['../class_kalendarz_1_1_days.html#a0e689437ac4d4e51036834645e480e41',1,'Kalendarz::Days']]]
];
