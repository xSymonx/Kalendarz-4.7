var searchData=
[
  ['static_5fday_0',['static_day',['../classKalendarz_1_1Days.html#a0e800cc7d36d534024a347d266b0daf1',1,'Kalendarz::Days']]]
];
