var searchData=
[
  ['showtasks_0',['ShowTasks',['../class_kalendarz_1_1_days.html#a180fc231deb7194b64cd0fef84a08f1c',1,'Kalendarz.Days.ShowTasks()'],['../class_kalendarz_1_1_main_window.html#ada03381bcce85895f347ed2c9cc6b4e6',1,'Kalendarz.MainWindow.ShowTasks()']]]
];
