var searchData=
[
  ['weather_5fwindow_0',['Weather_Window',['../class_kalendarz_1_1_weather___window.html#a9422f9b7093ebee225b4fa0b4c258821',1,'Kalendarz::Weather_Window']]]
];
