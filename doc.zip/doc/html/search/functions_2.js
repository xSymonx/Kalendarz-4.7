var searchData=
[
  ['days_0',['days',['../class_kalendarz_1_1_days.html#a420b4554d0ed8dec72e9d74eb71bf05b',1,'Kalendarz::Days']]],
  ['days_1',['Days',['../class_kalendarz_1_1_days.html#af45e8bbc0f52fdbd9b327191d8e36078',1,'Kalendarz::Days']]],
  ['delete_5ftask_5fwindow_2',['Delete_Task_Window',['../class_kalendarz_1_1_delete___task___window.html#a43fbf2273185f9fca6cb81273dc12c7b',1,'Kalendarz::Delete_Task_Window']]],
  ['deletetask_3',['DeleteTask',['../class_kalendarz_1_1_delete___task___window.html#a178bb5c3e6667d07ac45f9d11b7dc438',1,'Kalendarz::Delete_Task_Window']]]
];
