var searchData=
[
  ['taskcontext_0',['TaskContext',['../classKalendarz_1_1TaskContext.html#a87f06f308e74b76a300fc48728e18ce4',1,'Kalendarz::TaskContext']]],
  ['tasks_5fbutton_5fclick_1',['TASKS_BUTTON_Click',['../classKalendarz_1_1MainWindow.html#aadd443edc7f92887b30b111fc8974c9b',1,'Kalendarz::MainWindow']]]
];
