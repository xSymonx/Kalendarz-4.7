var searchData=
[
  ['readme_0',['README',['../md__c___users_dell_source_repos_x_symonx__kalendarz_4_7__r_e_a_d_m_e.html',1,'']]]
];
