var searchData=
[
  ['readme_0',['README',['../md_C__Users_dell_source_repos_xSymonx_Kalendarz_4_7_README.html',1,'']]]
];
