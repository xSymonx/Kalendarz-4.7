var searchData=
[
  ['add_5ftask_5fwindow_0',['Add_Task_Window',['../class_kalendarz_1_1_add___task___window.html#a71d88e8e91eebbb6d7ff6e1e94afbb88',1,'Kalendarz.Add_Task_Window.Add_Task_Window()'],['../class_kalendarz_1_1_add___task___window.html',1,'Kalendarz.Add_Task_Window']]],
  ['addnewtask_1',['AddNewTask',['../class_kalendarz_1_1_add___task___window.html#a0570d44915c2802ad49dcfdffa90d2f5',1,'Kalendarz::Add_Task_Window']]],
  ['app_2',['App',['../class_kalendarz_1_1_app.html',1,'Kalendarz']]]
];
