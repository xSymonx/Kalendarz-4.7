var indexSectionsWithContent =
{
  0: "abcdikmnrstuw",
  1: "abcdmstw",
  2: "k",
  3: "abdmrsuw",
  4: "s",
  5: "bdimnst",
  6: "r"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "properties",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Properties",
  6: "Pages"
};

